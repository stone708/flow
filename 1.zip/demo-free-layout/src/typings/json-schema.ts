import type { IJsonSchema, IBasicJsonSchema } from '@flowgram.ai/form-materials';

export type BasicType = IBasicJsonSchema;
export type JsonSchema = IJsonSchema;
