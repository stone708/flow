export const HEADER_HEIGHT = 30;
export const HEADER_PADDING = 5;

export enum GroupField {
  Title = 'title',
  Color = 'color',
}
