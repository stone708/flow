import './index.css';

export { CommentRender } from './render';
