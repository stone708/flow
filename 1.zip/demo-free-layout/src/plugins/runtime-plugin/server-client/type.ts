export interface ServerError {
  code: string;
  message: string;
}
