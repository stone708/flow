export { Editor as DemoFreeLayout } from './editor';
