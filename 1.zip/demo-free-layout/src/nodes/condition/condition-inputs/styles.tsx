import styled from 'styled-components';

export const ConditionPort = styled.div`
  position: absolute;
  right: -12px;
  top: 50%;
`;
